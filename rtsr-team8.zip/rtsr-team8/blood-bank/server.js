const express = require('express');
const { MongoClient } = require('mongodb');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;

// MongoDB connection URI
const uri = 'mongodb://localhost:27017/'; // Replace 'your_database_name' with your actual database name

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

let db;

(async () => {
    const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
    try {
        await client.connect();
        db = client.db();
        console.log('Connected to MongoDB');
        
        // Start the server after the database connection is established
        app.listen(PORT, () => {
            console.log(`Server running at http://localhost:${PORT}`);
        });
    } catch (error) {
        console.error('Error connecting to MongoDB:', error);
    }
})();

// Register user
app.post('/register', async (req, res) => {
    const { name, email, password } = req.body;

    try {
        const collection = db.collection('registration');
        await collection.insertOne({ name, email, password });
        res.status(201).json({ success: true, message: 'User registered successfully' });
    } catch (error) {
        console.error('Error registering user:', error);
        res.status(500).json({ success: false, message: 'An error occurred while registering user' });
    }
});
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ success: false, message: 'Email and password are required' });
    }

    const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    try {
        await client.connect();
        const database = client.db();
        const collection = database.collection('registration');
        const loginCollection = database.collection('logins');

        // Find user by email and password
        const user = await collection.findOne({ email, password });

        if (user) {
            // Log successful login attempt
            const loginTime = new Date();
            const loginRecord = {
                email,
                loginTime,
                ipAddress: req.ip // IP address of the user
            };
            await loginCollection.insertOne(loginRecord);

            // Send response with user data
            res.status(200).json({ success: true, message: 'Login successful', userData: user });
        } else {
            res.status(401).json({ success: false, message: 'Invalid email or password' });
        }
    } catch (error) {
        console.error('Error logging in:', error);
        res.status(500).json({ success: false, message: 'An error occurred while logging in' });
    } finally {
        await client.close();
    }
});


// Donate blood
app.post('/donate', async (req, res) => {
    const donorData = req.body;
    try {
        const result = await db.collection('donors').insertOne(donorData);
        res.json({ success: true, message: 'Donation Successful!', donorId: result.insertedId });
    } catch (error) {
        console.error('Error donating blood:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
});

// Fetch donor data
app.get('/donorData', async (req, res) => {
    try {
        const donors = await db.collection('donors').find({}).toArray();
        res.json({ success: true, donors });
    } catch (error) {
        console.error('Error fetching donor data:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
});
// Handle form submission and store data in MongoDB
app.post('/contact', async (req, res) => {
    const { name, email, phone, message } = req.body;

    try {
        const collection = db.collection('contact_messages');
        await collection.insertOne({ name, email, phone, message });
        res.status(201).json({ success: true, message: 'Message received and stored successfully' });
    } catch (error) {
        console.error('Error storing contact message:', error);
        res.status(500).json({ success: false, message: 'An error occurred while storing contact message' });
    }
});